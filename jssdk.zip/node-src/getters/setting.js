export const defaultSettings=state=>{
    return state.defaultSettings;
}