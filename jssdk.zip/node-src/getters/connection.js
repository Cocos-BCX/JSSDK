
export function isWsConnected(state) {
  return  state.wsConnected;
}

export function wsConnecting(state){
  return state.wsConnecting
}